const express = require("express")
const app = express()

//app.get('/', (req, res) => res.send("hello world!"))
app.use(express.static("www"))

app.listen(3000, () => console.log("Express app is running..."))